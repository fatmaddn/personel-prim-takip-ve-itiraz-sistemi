CREATE DATABASE  IF NOT EXISTS `vtys_proje` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `vtys_proje`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: vtys_proje
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appeals`
--

DROP TABLE IF EXISTS `appeals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appeals` (
  `itiraz_id` int NOT NULL AUTO_INCREMENT,
  `asistan_id` int NOT NULL,
  `prim_id` int NOT NULL,
  `itiraz_aciklamasi` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `itiraz_durumu` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `cevap` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`itiraz_id`),
  KEY `fk_appeals_asistan_id` (`asistan_id`),
  KEY `fk_prim_id` (`prim_id`),
  CONSTRAINT `fk_appeals_asistan_id` FOREIGN KEY (`asistan_id`) REFERENCES `asistans` (`asistan_id`),
  CONSTRAINT `fk_prim_id` FOREIGN KEY (`prim_id`) REFERENCES `bonuses` (`prim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appeals`
--

LOCK TABLES `appeals` WRITE;
/*!40000 ALTER TABLE `appeals` DISABLE KEYS */;
INSERT INTO `appeals` VALUES (1,1,1,'tekrar gözden geçirilsin','onaylandı','olumlu'),(3,1,2,'tekrar gözden geçirilmesini istiyorum','reddedildi','olumsuz'),(5,1,1,'itirazzz','reddedildi','olumsuz');
/*!40000 ALTER TABLE `appeals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asistans`
--

DROP TABLE IF EXISTS `asistans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asistans` (
  `asistan_id` int NOT NULL AUTO_INCREMENT,
  `sicil_no` int NOT NULL,
  `ad_soyad` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `takim_lider_id` int NOT NULL,
  PRIMARY KEY (`asistan_id`),
  KEY `fk_takim_lider_id` (`takim_lider_id`),
  CONSTRAINT `fk_takim_lider_id` FOREIGN KEY (`takim_lider_id`) REFERENCES `teamleaders` (`takim_lider_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asistans`
--

LOCK TABLES `asistans` WRITE;
/*!40000 ALTER TABLE `asistans` DISABLE KEYS */;
INSERT INTO `asistans` VALUES (1,132741,'Miraç Doğan',1);
/*!40000 ALTER TABLE `asistans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bonuscalculations`
--

DROP TABLE IF EXISTS `bonuscalculations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bonuscalculations` (
  `hesaplama_id` int NOT NULL AUTO_INCREMENT,
  `prim_id` int NOT NULL,
  `gorusme_sayisi` int NOT NULL,
  `kisa_gorusme_sayisi` int NOT NULL,
  `ay` int NOT NULL,
  `prim_miktari` int NOT NULL,
  PRIMARY KEY (`hesaplama_id`),
  KEY `fk_bc_prim_id` (`prim_id`),
  CONSTRAINT `fk_bc_prim_id` FOREIGN KEY (`prim_id`) REFERENCES `bonuses` (`prim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bonuscalculations`
--

LOCK TABLES `bonuscalculations` WRITE;
/*!40000 ALTER TABLE `bonuscalculations` DISABLE KEYS */;
INSERT INTO `bonuscalculations` VALUES (1,1,150,120,1,1);
/*!40000 ALTER TABLE `bonuscalculations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bonuses`
--

DROP TABLE IF EXISTS `bonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bonuses` (
  `prim_id` int NOT NULL,
  `asistan_id` int NOT NULL,
  `ay` int NOT NULL,
  `prim_tutari` int NOT NULL,
  PRIMARY KEY (`prim_id`),
  KEY `fk_asitan_id` (`asistan_id`),
  CONSTRAINT `fk_asitan_id` FOREIGN KEY (`asistan_id`) REFERENCES `asistans` (`asistan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bonuses`
--

LOCK TABLES `bonuses` WRITE;
/*!40000 ALTER TABLE `bonuses` DISABLE KEYS */;
INSERT INTO `bonuses` VALUES (1,1,1,200),(2,1,2,300);
/*!40000 ALTER TABLE `bonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calltopics`
--

DROP TABLE IF EXISTS `calltopics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calltopics` (
  `konu_id` int NOT NULL AUTO_INCREMENT,
  `konu` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `asistan_id` int NOT NULL,
  PRIMARY KEY (`konu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calltopics`
--

LOCK TABLES `calltopics` WRITE;
/*!40000 ALTER TABLE `calltopics` DISABLE KEYS */;
/*!40000 ALTER TABLE `calltopics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customercalls`
--

DROP TABLE IF EXISTS `customercalls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customercalls` (
  `gorusme_id` int NOT NULL AUTO_INCREMENT,
  `asistan_id` int NOT NULL,
  `musteri_ad_soyad` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `gorusme_konusu` varchar(5) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `gorusme_tarihi` date NOT NULL,
  `baslama_saati` time NOT NULL,
  `bitis_saati` time NOT NULL,
  `gorusme_durumu` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`gorusme_id`),
  KEY `fk_asistan_id` (`asistan_id`),
  CONSTRAINT `fk_asistan_id` FOREIGN KEY (`asistan_id`) REFERENCES `asistans` (`asistan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customercalls`
--

LOCK TABLES `customercalls` WRITE;
/*!40000 ALTER TABLE `customercalls` DISABLE KEYS */;
INSERT INTO `customercalls` VALUES (2,1,'Mustafa Arslan','arıza','2024-05-23','14:50:00','15:50:00','tamamlandı'),(11,1,'esat çiçek','arıza','2024-05-09','07:00:00','08:00:00','tamamlandı'),(12,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(13,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(14,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(15,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(16,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(17,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(18,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(19,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(20,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(21,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(22,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(23,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(24,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(25,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(26,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(27,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(28,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(29,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(30,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(31,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(32,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(33,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(34,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(35,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(36,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(37,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(38,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(39,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(40,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(41,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(42,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(43,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(44,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(45,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(46,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(47,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(48,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(49,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(50,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(51,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(52,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(53,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(54,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(55,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(56,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(57,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(58,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(59,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(60,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(61,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(62,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(63,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(64,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(65,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(66,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(67,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(68,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(69,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(70,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(71,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(72,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(73,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(74,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(75,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(76,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(77,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(78,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(79,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(80,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(81,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(82,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(83,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(84,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(85,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(86,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(87,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(88,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(89,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(90,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(91,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(92,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(93,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(94,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(95,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(96,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(97,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(98,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(99,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(100,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(101,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(102,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(103,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(104,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(105,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(106,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(107,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(108,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(109,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(110,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(111,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(112,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(113,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(114,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(115,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(116,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(117,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(118,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(119,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(120,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(121,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(122,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(123,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(124,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(125,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(126,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(127,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(128,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(129,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(130,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(131,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(132,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(133,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(134,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(135,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(136,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(137,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(138,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(139,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(140,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(141,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(142,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(143,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(144,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(145,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(146,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(147,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(148,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(149,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(150,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(151,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor'),(152,1,'Ahmet Yılmaz','Arıza','2024-05-25','09:00:00','09:10:00','Tamamlandı'),(153,1,'Ayşe Kaya','Talep','2024-05-26','10:00:00','10:15:00','Takip ediliyor'),(154,1,'Mehmet Demir','Bilgi','2024-05-27','11:00:00','11:20:00','Sorun çözülemedi'),(155,1,'Fatma Yılmaz','Arıza','2024-05-28','13:00:00','13:15:00','Tamamlandı'),(156,1,'Ali Kaya','Talep','2024-05-29','14:00:00','14:10:00','Tamamlandı'),(157,1,'Zeynep Demir','Bilgi','2024-05-30','15:00:00','15:30:00','Sorun çözülemedi'),(158,1,'Mustafa Yılmaz','Arıza','2024-06-01','09:30:00','09:45:00','Takip ediliyor'),(159,1,'Aylin Kaya','Talep','2024-06-02','10:30:00','10:45:00','Tamamlandı'),(160,1,'Sema Demir','Bilgi','2024-06-03','11:30:00','11:45:00','Tamamlandı'),(161,1,'Burak Yılmaz','Arıza','2024-06-04','13:30:00','13:40:00','Sorun çözülemedi'),(162,1,'Ebru Kaya','Talep','2024-06-05','14:30:00','14:40:00','Takip ediliyor'),(163,1,'Emre Demir','Bilgi','2024-06-06','15:30:00','15:45:00','Sorun çözülemedi'),(164,1,'Can Yılmaz','Arıza','2024-06-07','09:15:00','09:30:00','Tamamlandı'),(165,1,'Gülay Kaya','Talep','2024-06-08','10:15:00','10:30:00','Tamamlandı'),(166,1,'Osman Demir','Bilgi','2024-06-09','11:15:00','11:30:00','Sorun çözülemedi'),(167,1,'Ayşenur Yılmaz','Arıza','2024-06-10','13:15:00','13:30:00','Takip ediliyor');
/*!40000 ALTER TABLE `customercalls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2024-05-23 10:55:35.239949'),(2,'auth','0001_initial','2024-05-23 10:55:37.326988'),(3,'admin','0001_initial','2024-05-23 10:55:37.742316'),(4,'admin','0002_logentry_remove_auto_add','2024-05-23 10:55:37.764032'),(5,'admin','0003_logentry_add_action_flag_choices','2024-05-23 10:55:37.782032'),(6,'contenttypes','0002_remove_content_type_name','2024-05-23 10:55:38.069962'),(7,'auth','0002_alter_permission_name_max_length','2024-05-23 10:55:38.276351'),(8,'auth','0003_alter_user_email_max_length','2024-05-23 10:55:38.347478'),(9,'auth','0004_alter_user_username_opts','2024-05-23 10:55:38.365729'),(10,'auth','0005_alter_user_last_login_null','2024-05-23 10:55:38.517202'),(11,'auth','0006_require_contenttypes_0002','2024-05-23 10:55:38.531417'),(12,'auth','0007_alter_validators_add_error_messages','2024-05-23 10:55:38.554854'),(13,'auth','0008_alter_user_username_max_length','2024-05-23 10:55:38.797176'),(14,'auth','0009_alter_user_last_name_max_length','2024-05-23 10:55:39.016891'),(15,'auth','0010_alter_group_name_max_length','2024-05-23 10:55:39.073111'),(16,'auth','0011_update_proxy_permissions','2024-05-23 10:55:39.095012'),(17,'auth','0012_alter_user_first_name_max_length','2024-05-23 10:55:39.285784'),(18,'auth','0013_alter_user_username','2024-05-23 10:55:39.476790'),(19,'auth','0014_alter_user_username','2024-05-23 10:55:39.667147'),(20,'sessions','0001_initial','2024-05-23 10:55:39.816894');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('q8u1vbc3cj7tzt3wprg8xfjkh8aa1efi','.eJyrVsouzclJzMtMzoxPTMlUslLKLS0uSUxLNDFV0lEqys8BipQkZseUGhgaG-Yq5GSmpBZlAmWKgRpy4vPylazMTQwtTI10kMzJTFGyMqoFAFgbHW4:1sAVxl:AQHxlP4z6i_xqOrgh9h-365EsWR4KZH9xgi0NOMRWcU','2024-06-07 14:32:05.453392'),('zfk4tnbgxjucifanvps53qc4upyr78k8','eyJrdWxsYW5jaV9pZCI6Miwia3VsbGFuaWNpX2FkaSI6Im1yY2RnbiIsInJvbCI6ImFzaXN0YW4ifQ:1sABJQ:_YmpyqQ_BaPscyf9oappguqAPMrVSPzuTCXeA1_BeNE','2024-06-06 16:29:04.217142');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gorusmedurumlari`
--

DROP TABLE IF EXISTS `gorusmedurumlari`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gorusmedurumlari` (
  `durum_id` int NOT NULL AUTO_INCREMENT,
  `durum` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`durum_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gorusmedurumlari`
--

LOCK TABLES `gorusmedurumlari` WRITE;
/*!40000 ALTER TABLE `gorusmedurumlari` DISABLE KEYS */;
/*!40000 ALTER TABLE `gorusmedurumlari` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupmanagers`
--

DROP TABLE IF EXISTS `groupmanagers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupmanagers` (
  `grup_yonetici_id` int NOT NULL AUTO_INCREMENT,
  `ad_soyad` varchar(45) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`grup_yonetici_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupmanagers`
--

LOCK TABLES `groupmanagers` WRITE;
/*!40000 ALTER TABLE `groupmanagers` DISABLE KEYS */;
INSERT INTO `groupmanagers` VALUES (1,'Murat Keskin');
/*!40000 ALTER TABLE `groupmanagers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teamleaders`
--

DROP TABLE IF EXISTS `teamleaders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teamleaders` (
  `takim_lider_id` int NOT NULL AUTO_INCREMENT,
  `ad_soyad` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `sicil_no` int DEFAULT NULL,
  `grup_yonetici_id` int NOT NULL,
  PRIMARY KEY (`takim_lider_id`),
  KEY `fk_grup_yonetici_id` (`grup_yonetici_id`),
  CONSTRAINT `fk_grup_yonetici_id` FOREIGN KEY (`grup_yonetici_id`) REFERENCES `groupmanagers` (`grup_yonetici_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teamleaders`
--

LOCK TABLES `teamleaders` WRITE;
/*!40000 ALTER TABLE `teamleaders` DISABLE KEYS */;
INSERT INTO `teamleaders` VALUES (1,'Musatafa Doğan',741852,1);
/*!40000 ALTER TABLE `teamleaders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `kullanici_id` int NOT NULL AUTO_INCREMENT,
  `kullanici_adi` varchar(45) NOT NULL,
  `sifre` varchar(15) NOT NULL,
  `rol` varchar(25) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `sicil_no` int DEFAULT NULL,
  PRIMARY KEY (`kullanici_id`),
  UNIQUE KEY `sicil_no_UNIQUE` (`sicil_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'mrcdgn','123','asistan',132741),(2,'mustafa45','123','takım lideri',741852),(3,'umit35','123','grup yöneticisi',852963);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'vtys_proje'
--
/*!50003 DROP FUNCTION IF EXISTS `fn_GetMonthlyCallCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_GetMonthlyCallCount`(assistant_id INT, month DATE) RETURNS int
    DETERMINISTIC
BEGIN
    DECLARE total_calls INT;

    SELECT COUNT(*) INTO total_calls
    FROM customer_calls
    WHERE assistant_id = assistant_id
    AND MONTH(call_date) = MONTH(month)
    AND YEAR(call_date) = YEAR(month);

    RETURN total_calls;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getDistinctAsistanIDs` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `getDistinctAsistanIDs`()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE asistan_id_val INT;
    DECLARE cur CURSOR FOR SELECT DISTINCT asistan_id FROM customercalls;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO asistan_id_val;
        IF done THEN
            LEAVE read_loop;
        END IF;
        -- Burada asistan_id ile yapılacak işlemleri yapabilirsiniz
        -- Örneğin, asistan_id değerini ekrana yazdıralım
        SELECT asistan_id_val;
    END LOOP;

    CLOSE cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_GetMonthlyCallCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_GetMonthlyCallCount`(assistant_id INT, month DATE)
BEGIN
    DECLARE total_calls INT;

    SELECT COUNT(*)
    INTO total_calls
    FROM customercalls
    WHERE assistant_id = assistant_id
    AND MONTH(gorusme_tarihi) = MONTH(month)
    AND YEAR(gorusme_tarihi) = YEAR(month);

    SELECT total_calls;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-24 21:46:42
