from django.shortcuts import render, redirect
from .models import Asistans, Users, Teamleaders, Groupmanagers, Appeals, Customercalls,Bonuses
from datetime import datetime
from django.contrib import messages


#  Create your views here.


def homePage(request):

    # Oturumda kullanıcı var mı yokmu kontrol edelim
    kullanici_id = request.session.get('kullanici_id')
    kullanici_adi = request.session.get('kullanici_adi')
    sicil_no = request.session.get('sicil_no')

    rol = request.session.get('rol')

    if kullanici_id:
        context = {
            'kullanici': {
                'kullanici_id': kullanici_id,
                'kullanici_adi': kullanici_adi,
                'rol': rol,
                'sicil_no': sicil_no
            }
        }
        print('kullaniciAdi', kullanici_adi, rol, sicil_no)

        if rol == 'asistan':
            return redirect('asistanPage')

        elif rol == 'takım lideri':
            return redirect('teamLeaderPage')

        

        return render(request, 'index.html', context)
    else:
        # oturum Yoksa giriş sayfasına Yönlendir
        return redirect('loginPage')


def loginPage(request):

    if request.method == 'POST':

        kullanici_adi = request.POST.get('username')
        sifre = request.POST.get('password')
        user = Users.objects.filter(
            kullanici_adi=kullanici_adi, sifre=sifre).first()

        if user:
            # oturumu başlatmak için session kullanalım
            request.session['kullanici_id'] = user.kullanici_id
            request.session['kullanici_adi'] = user.kullanici_adi
            request.session['sicil_no'] = user.sicil_no

            request.session['rol'] = user.rol

            print(kullanici_adi, sifre, user.rol, user.sicil_no)
            return redirect('homePage')
        else:
            context = {'error': 'kullanıcı adı veya parola hatalı'}
            return render(request, 'partials/login.html', context)

    # Get isteği için anasayfayı render edelim
    return render(request, 'partials/login.html')


def logout(request):
    if 'kullanici_id' in request.session:
        del request.session['kullanici_id']
    return redirect('homePage')

def asistanPage(request):

    return render(request, 'partials/asistanPage.html')


def musteriCagriListesi(request):
    # HTTP GET ve POST isteklerini işleyelim
    if request.method == 'GET':
        # Tüm müşteri çağrılarını alalım
        callList = Customercalls.objects.all()
        # print(callList)
        # Müşteri çağrısı listesini şablona aktaralım
        context = {'callList': callList}
        return render(request, 'partials/callList.html', context)

 # HTTP POST isteği alındığında form verilerini işleyelim
    if request.method == 'POST':
        # Gizli alanı kontrol edin
        form_type = request.POST.get('form_type', None)
        if form_type == 'add_customer':
            musteri_ad_soyad = request.POST.get('musteriBilgileri')
            gorusme_konusu = request.POST.get('gorusmeKonusu')
            gorusme_tarihi = request.POST.get('gorusmeTarihi')
            baslama_saati = request.POST.get('startTime')
            bitis_saati = request.POST.get('endTime')
            gorusme_durumu = request.POST.get('gorusmeDurumu')

            # Tüm gerekli alanlar doldurulmuş mu?
            if musteri_ad_soyad and gorusme_konusu and gorusme_tarihi and baslama_saati and bitis_saati and gorusme_durumu:

                rol = request.session.get('rol')

                if rol == 'asistan':
                    user = Users.objects.get(
                    kullanici_adi=request.session.get('kullanici_adi'))
                    print(user.sicil_no)
                    asistan = Asistans.objects.get(sicil_no=user.sicil_no)

                    print(musteri_ad_soyad, " ,", gorusme_konusu, ' ,',
                          gorusme_tarihi, ' ,', baslama_saati, ' ,', bitis_saati, ' ,')

                    new_cust = Customercalls.objects.create(
                        asistan_id=asistan.asistan_id,
                        musteri_ad_soyad=musteri_ad_soyad,
                        gorusme_konusu=gorusme_konusu,
                        gorusme_tarihi=gorusme_tarihi,
                        baslama_saati=baslama_saati,
                        bitis_saati=bitis_saati,
                        gorusme_durumu=gorusme_durumu
                    )
                    new_cust.save()
                    print('kayıt başarılı')
                else:
                    # Tüm alanları Doldurunuz
                    context = {'error': 'Tüm alanları doldurmalısınız'}

                    return render(request, 'partials/callList.html', context)
    # Yanlış bir HTTP isteği alındığında, varsayılan olarak ana sayfaya yönlendirme
    return redirect('homePage')


def primListesi(request):

    user = Users.objects.get(kullanici_adi = request.session.get('kullanici_adi'))
    asistan = Asistans.objects.get(sicil_no = user.sicil_no)
    
    prim_list = Bonuses.objects.filter(asistan_id= asistan.asistan_id)

    context = {'prim_list':prim_list}

    return render(request,'partials/primListesi.html',context)


def primItiraz(request):

    if request.method == 'POST':
        prim_id = request.POST.get('prim_id')
        itiraz_aciklamasi = request.POST.get('itiraz_aciklamasi')

        if prim_id and itiraz_aciklamasi:
            user = Users.objects.get(kullanici_adi =request.session.get('kullanici_adi'))
            asistan = Asistans.objects.get(sicil_no = user.sicil_no)
            prim = Bonuses.objects.get(prim_id = prim_id)
            
            new_appeal = Appeals.objects.create(
                asistan_id = asistan.asistan_id,
                prim = prim ,
                itiraz_aciklamasi = itiraz_aciklamasi,
                itiraz_durumu = 'bekliyor',
                cevap = 'henüz Yanıtlanmandı'
            )

            new_appeal.save()
            messages.success(request,'itiraz kaydınızı başarıyla oluşturuldu')

            return redirect('primListesi')
        
    messages.error(request,'İtiraz kaydı oluşturulamadı . Lütfen Tüm alanları Doldurunuz')
    return redirect('primListesi')



def itirazlar(request):


    user = Users.objects.get(kullanici_adi = request.session.get('kullanici_adi'))
    asistan = Asistans.objects.get(sicil_no = user.sicil_no)
    print(asistan.asistan_id)
    itirazlar = Appeals.objects.filter(asistan_id = asistan.asistan_id)

    context = {'itirazlar':itirazlar}
    return render(request,'partials/itirazlar.html',context)

def teamLeader(request):

    user = Users.objects.get(kullanici_adi = request.session.get('kullanici_adi'))
    print(user.sicil_no)

    team_leader= Teamleaders.objects.get(sicil_no = user.sicil_no)

    asistan = Asistans.objects.get(takim_lider_id = team_leader.takim_lider_id)

    appeals = Appeals.objects.filter(asistan_id = asistan.asistan_id)
    
    context = {
            'asistan':asistan,
            'itirazlar' : appeals
        }

    print(asistan.ad_soyad)
    print(team_leader.takim_lider_id)
    
    return render(request,'partials/teamLeaderPage.html',context)

def yanitla_sayfasi(request,itiraz_id):

    print(itiraz_id)

    appeal = Appeals.objects.get(itiraz_id = itiraz_id)
    
    asistan = Asistans.objects.get(asistan_id = appeal.asistan_id)

    if request.method == 'POST':

        yanit = request.POST.get('yanit_secim')
        print(yanit)

        if yanit == 'olumlu':
            print('girdi')
            appeal.itiraz_durumu = 'onaylandı'
            appeal.cevap = yanit
            appeal.save()
            return redirect('teamLeaderPage')

        elif yanit == 'olumsuz':
            appeal.itiraz_durumu ='reddedildi'
            appeal.cevap = yanit
            appeal.save()
            return redirect('teamLeaderPage')
   



    context = {
        'itiraz':appeal,
        'asistan':asistan
        
        }

    return render(request, 'partials/yanitla_sayfasi.html',context)