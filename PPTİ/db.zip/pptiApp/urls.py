from django.urls import path
from .views import homePage , loginPage,logout ,asistanPage,musteriCagriListesi,primListesi,primItiraz , itirazlar , teamLeader,yanitla_sayfasi

urlpatterns = [
    path('',homePage,name="homePage"),
    path('login',loginPage,name="loginPage"),
    path('logout/',logout,name="logout"),
    path('asistanPage',asistanPage,name='asistanPage'),
    path('asistanPage/musteri-cagri-listesi',musteriCagriListesi,name="cagriPage"),
    
    path('asistanPage/prim-listesi',primListesi,name="primListesi"),
    path('asistanPage/itiraz',primItiraz,name='primItiraz'),
    path('asistanPage/itirazlar-listesi',itirazlar,name="itirazlar"),

    path('team-leader-page/',teamLeader,name="teamLeaderPage"),
    
    path('team-leader-page/<int:itiraz_id>/',yanitla_sayfasi,name="yanitla_sayfasi")
]
