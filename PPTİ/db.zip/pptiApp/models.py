from django.db import models
from django.utils import timezone

# Create your models here.


class Appeals(models.Model):
    itiraz_id = models.AutoField(primary_key=True)
    asistan = models.ForeignKey('Asistans', models.DO_NOTHING)
    prim = models.ForeignKey('Bonuses', models.DO_NOTHING)
    itiraz_aciklamasi = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')
    itiraz_durumu = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')
    cevap = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')

    class Meta:
        managed = True
        db_table = 'appeals'

class Asistans(models.Model):
    asistan_id = models.AutoField(primary_key=True)
    sicil_no = models.IntegerField()
    ad_soyad = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')
    takim_lider = models.ForeignKey('Teamleaders', models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'asistans'

class Gorusmedurumlari(models.Model):
    durum_id = models.AutoField(primary_key=True)
    durum = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')

    class Meta:
        managed = True
        db_table = 'gorusmedurumlari'

class Groupmanagers(models.Model):
    grup_yonetici_id = models.AutoField(primary_key=True)
    ad_soyad = models.CharField(max_length=45, db_collation='utf8mb3_general_ci')

    class Meta:
        managed = True
        db_table = 'groupmanagers'

class Teamleaders(models.Model):
    takim_lider_id = models.AutoField(primary_key=True)
    ad_soyad = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')
    sicil_no = models.IntegerField(default=1)
    grup_yonetici = models.ForeignKey(Groupmanagers, models.DO_NOTHING)

    class Meta:
        managed = True
        db_table = 'teamleaders'

class Users(models.Model):
    kullanici_id = models.AutoField(primary_key=True)
    kullanici_adi = models.CharField(max_length=45, db_collation='utf8mb3_general_ci')
    sifre = models.CharField(max_length=15)
    rol = models.CharField(max_length=25, db_collation='utf8mb3_general_ci')
    sicil_no = models.IntegerField(unique=True, blank=True, null=True)
    
    class Meta:
        managed = True
        db_table = 'users'

class Bonuscalculations(models.Model):
    hesaplama_id = models.AutoField(primary_key=True)
    prim = models.ForeignKey('Bonuses', models.DO_NOTHING)
    gorusme_sayisi = models.IntegerField()
    kisa_gorusme_sayisi = models.IntegerField()
    ay = models.IntegerField()
    prim_miktari = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'bonuscalculations'

class Bonuses(models.Model):
    prim_id = models.AutoField(primary_key=True, auto_created=True)
    asistan = models.ForeignKey(Asistans, models.DO_NOTHING)
    ay = models.IntegerField()
    prim_tutari = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'bonuses'

class Calltopics(models.Model):
    konu_id = models.AutoField(primary_key=True)
    konu = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')
    asistan_id = models.IntegerField()

    class Meta:
        managed = True
        db_table = 'calltopics'

class Customercalls(models.Model):
    gorusme_id = models.AutoField(primary_key=True)
    asistan = models.ForeignKey(Asistans, on_delete=models.DO_NOTHING)
    musteri_ad_soyad = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')
    gorusme_konusu = models.CharField(max_length=5, db_collation='utf8mb3_general_ci')
    gorusme_tarihi = models.DateField()
    baslama_saati = models.TimeField()
    bitis_saati = models.TimeField()
    gorusme_durumu = models.CharField(max_length=50, db_collation='utf8mb3_general_ci')

    class Meta:
        managed = True
        db_table = 'customercalls'

